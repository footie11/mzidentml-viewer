#!/bin/bash
java -jar ProteoIDViewer.jar
